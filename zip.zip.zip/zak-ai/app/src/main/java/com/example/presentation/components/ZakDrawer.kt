package com.example.presentation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.database.entity.ConversationEntity
import com.example.core.model.UserProfile
import com.example.presentation.navigation.Screen
import com.example.ui.theme.ZakElectricBlue
import com.example.ui.theme.ZakLuminousCyan
import com.example.ui.theme.ZakSubtleCyan

@Composable
fun ZakDrawer(
    currentRoute: String,
    currentConversationId: String?,
    recentConversations: List<ConversationEntity>,
    userProfile: UserProfile,
    onNavigate: (String) -> Unit,
    onSelectConversation: (String) -> Unit,
    onDeleteConversation: (String) -> Unit,
    onCloseDrawer: () -> Unit,
    modifier: Modifier = Modifier
) {
    ModalDrawerSheet(
        modifier = modifier
            .width(310.dp)
            .fillMaxHeight(),
        drawerContainerColor = MaterialTheme.colorScheme.surface,
        drawerContentColor = MaterialTheme.colorScheme.onSurface,
        drawerShape = RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .statusBarsPadding()
                .padding(vertical = 12.dp)
        ) {
            // Header: ZAK AI Brand
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ZakLogo(size = 36.dp)
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "ZAK AI",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )
                    Text(
                        text = "Intelligence Systems",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = ZakSubtleCyan,
                            fontSize = 11.sp,
                            letterSpacing = 0.5.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(
                modifier = Modifier.padding(horizontal = 16.dp),
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
            )
            Spacer(modifier = Modifier.height(8.dp))

            // Primary Navigation Items
            Column(modifier = Modifier.padding(horizontal = 12.dp)) {
                DrawerNavItem(
                    title = "New Chat",
                    icon = Icons.Default.Add,
                    isSelected = currentRoute == Screen.Chat.route && currentConversationId == null,
                    accentColor = ZakElectricBlue,
                    onClick = {
                        onNavigate(Screen.Chat.route)
                        onCloseDrawer()
                    }
                )
                DrawerNavItem(
                    title = "Search Chat",
                    icon = Icons.Default.Search,
                    isSelected = currentRoute == Screen.Search.route,
                    onClick = {
                        onNavigate(Screen.Search.route)
                        onCloseDrawer()
                    }
                )
                DrawerNavItem(
                    title = "Studio",
                    icon = Icons.Default.AutoAwesome,
                    isSelected = currentRoute == Screen.Studio.route,
                    onClick = {
                        onNavigate(Screen.Studio.route)
                        onCloseDrawer()
                    }
                )
                DrawerNavItem(
                    title = "Memory",
                    icon = Icons.Default.Psychology,
                    isSelected = currentRoute == Screen.Memory.route,
                    onClick = {
                        onNavigate(Screen.Memory.route)
                        onCloseDrawer()
                    }
                )
                DrawerNavItem(
                    title = "Coding Evolution",
                    icon = Icons.Default.Code,
                    isSelected = currentRoute == Screen.Coding.route,
                    onClick = {
                        onNavigate(Screen.Coding.route)
                        onCloseDrawer()
                    }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // RECENTS Section
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "RECENTS",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        letterSpacing = 1.2.sp
                    )
                )
            }

            // Recent Conversations List
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
            ) {
                if (recentConversations.isEmpty()) {
                    item {
                        Text(
                            text = "No recent chats yet",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                fontSize = 12.sp
                            ),
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 16.dp)
                        )
                    }
                } else {
                    items(recentConversations, key = { it.id }) { conv ->
                        val isSelected = currentConversationId == conv.id && currentRoute == Screen.Chat.route
                        RecentChatItem(
                            conversation = conv,
                            isSelected = isSelected,
                            onSelect = {
                                onSelectConversation(conv.id)
                                onCloseDrawer()
                            },
                            onDelete = { onDeleteConversation(conv.id) }
                        )
                    }
                }
            }

            HorizontalDivider(
                modifier = Modifier.padding(horizontal = 16.dp),
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
            )
            Spacer(modifier = Modifier.height(8.dp))

            // Bottom Profile and Settings
            Column(modifier = Modifier.padding(horizontal = 12.dp)) {
                DrawerNavItem(
                    title = "Profile",
                    icon = Icons.Outlined.Person,
                    isSelected = currentRoute == Screen.Profile.route,
                    subtitle = userProfile.name,
                    onClick = {
                        onNavigate(Screen.Profile.route)
                        onCloseDrawer()
                    }
                )
                DrawerNavItem(
                    title = "Settings",
                    icon = Icons.Default.Settings,
                    isSelected = currentRoute == Screen.Settings.route,
                    onClick = {
                        onNavigate(Screen.Settings.route)
                        onCloseDrawer()
                    }
                )
            }
        }
    }
}

@Composable
private fun DrawerNavItem(
    title: String,
    icon: ImageVector,
    isSelected: Boolean,
    subtitle: String? = null,
    accentColor: Color? = null,
    onClick: () -> Unit
) {
    val backgroundColor = if (isSelected) {
        (accentColor ?: ZakElectricBlue).copy(alpha = 0.15f)
    } else Color.Transparent

    val contentColor = if (isSelected) {
        ZakLuminousCyan
    } else MaterialTheme.colorScheme.onSurface

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(backgroundColor)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = contentColor,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                    color = contentColor,
                    fontSize = 14.sp
                )
            )
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp
                    )
                )
            }
        }
    }
}

@Composable
private fun RecentChatItem(
    conversation: ConversationEntity,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onDelete: () -> Unit
) {
    val backgroundColor = if (isSelected) {
        MaterialTheme.colorScheme.surfaceVariant
    } else Color.Transparent

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(backgroundColor)
            .clickable(onClick = onSelect)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Default.ChatBubbleOutline,
            contentDescription = null,
            tint = if (isSelected) ZakSubtleCyan else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = conversation.title,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontSize = 13.sp,
                color = if (isSelected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
            ),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        IconButton(
            onClick = onDelete,
            modifier = Modifier.size(24.dp)
        ) {
            Icon(
                imageVector = Icons.Default.DeleteOutline,
                contentDescription = "Delete chat",
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier.size(16.dp)
            )
        }
    }
}
