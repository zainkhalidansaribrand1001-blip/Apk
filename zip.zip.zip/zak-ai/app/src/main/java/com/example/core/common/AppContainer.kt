package com.example.core.common

import android.content.Context
import com.example.core.database.AppDatabase
import com.example.core.network.AiService
import com.example.core.network.AiServiceImpl
import com.example.data.repository.ChatRepositoryImpl
import com.example.data.repository.MemoryRepositoryImpl
import com.example.data.repository.SettingsRepositoryImpl
import com.example.domain.repository.ChatRepository
import com.example.domain.repository.MemoryRepository
import com.example.domain.repository.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.runBlocking

interface AppContainer {
    val database: AppDatabase
    val chatRepository: ChatRepository
    val memoryRepository: MemoryRepository
    val settingsRepository: SettingsRepository
    val aiService: AiService
    val networkMonitor: NetworkMonitor
}

class DefaultAppContainer(private val context: Context) : AppContainer {

    override val database: AppDatabase by lazy {
        AppDatabase.getInstance(context)
    }

    override val chatRepository: ChatRepository by lazy {
        ChatRepositoryImpl(
            conversationDao = database.conversationDao(),
            messageDao = database.messageDao()
        )
    }

    override val memoryRepository: MemoryRepository by lazy {
        MemoryRepositoryImpl(
            memoryDao = database.memoryDao()
        )
    }

    override val settingsRepository: SettingsRepository by lazy {
        SettingsRepositoryImpl(context)
    }

    override val networkMonitor: NetworkMonitor by lazy {
        NetworkMonitor(context)
    }

    override val aiService: AiService by lazy {
        AiServiceImpl(
            context = context,
            customBackendUrlProvider = {
                runBlocking(Dispatchers.IO) {
                    settingsRepository.backendUrlFlow.firstOrNull()
                }
            },
            customDevKeyProvider = {
                runBlocking(Dispatchers.IO) {
                    settingsRepository.devApiKeyFlow.firstOrNull()
                }
            }
        )
    }
}
