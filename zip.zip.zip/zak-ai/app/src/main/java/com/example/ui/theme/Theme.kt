package com.example.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.example.core.model.ThemeMode

private val ZakDarkColorScheme = darkColorScheme(
    primary = ZakElectricBlue,
    onPrimary = Color.White,
    primaryContainer = ZakSurfaceElevatedDark,
    onPrimaryContainer = ZakLuminousCyan,
    secondary = ZakSubtleCyan,
    onSecondary = Color(0xFF032233),
    secondaryContainer = ZakSurfaceVariantDark,
    onSecondaryContainer = ZakLuminousCyan,
    tertiary = ZakLuminousCyan,
    background = ZakDeepCharcoal,
    onBackground = ZakTextPrimaryDark,
    surface = ZakSurfaceDark,
    onSurface = ZakTextPrimaryDark,
    surfaceVariant = ZakSurfaceVariantDark,
    onSurfaceVariant = ZakTextSecondaryDark,
    outline = ZakBorderDark,
    outlineVariant = ZakBorderSubtleDark,
    error = ZakError,
    onError = Color.White
)

private val ZakLightColorScheme = lightColorScheme(
    primary = ZakElectricBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDBEAFE),
    onPrimaryContainer = Color(0xFF1E3A8A),
    secondary = ZakSubtleCyan,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE0F2FE),
    onSecondaryContainer = Color(0xFF0369A1),
    tertiary = ZakElectricBlueLight,
    background = ZakLightBackground,
    onBackground = ZakLightTextPrimary,
    surface = ZakLightSurface,
    onSurface = ZakLightTextPrimary,
    surfaceVariant = ZakLightSurfaceVariant,
    onSurfaceVariant = ZakLightTextSecondary,
    outline = ZakLightBorder,
    outlineVariant = Color(0xFFCBD5E1),
    error = ZakError,
    onError = Color.White
)

@Composable
fun ZakAiTheme(
    themeMode: ThemeMode = ThemeMode.DARK,
    content: @Composable () -> Unit
) {
    val darkTheme = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }

    val colorScheme = if (darkTheme) ZakDarkColorScheme else ZakLightColorScheme

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = colorScheme.background.toArgb()
                window.navigationBarColor = colorScheme.background.toArgb()
                val insetsController = WindowCompat.getInsetsController(window, view)
                insetsController.isAppearanceLightStatusBars = !darkTheme
                insetsController.isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
