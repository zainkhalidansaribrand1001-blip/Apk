package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.core.model.ThemeMode
import com.example.presentation.chat.ChatScreen
import com.example.presentation.chat.ChatViewModel
import com.example.presentation.coding.CodingScreen
import com.example.presentation.coding.CodingViewModel
import com.example.presentation.memory.MemoryScreen
import com.example.presentation.memory.MemoryViewModel
import com.example.presentation.navigation.Screen
import com.example.presentation.profile.ProfileScreen
import com.example.presentation.profile.ProfileViewModel
import com.example.presentation.search.SearchScreen
import com.example.presentation.search.SearchViewModel
import com.example.presentation.settings.SettingsScreen
import com.example.presentation.settings.SettingsViewModel
import com.example.presentation.splash.SplashScreen
import com.example.presentation.studio.StudioScreen
import com.example.presentation.studio.StudioViewModel
import com.example.ui.theme.ZakAiTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val appContainer = (application as ZakAiApplication).container

        setContent {
            val themeMode by appContainer.settingsRepository.themeModeFlow.collectAsState(initial = ThemeMode.DARK)

            ZakAiTheme(themeMode = themeMode) {
                val navController = rememberNavController()

                NavHost(
                    navController = navController,
                    startDestination = Screen.Splash.route,
                    enterTransition = { fadeIn(animationSpec = tween(250)) },
                    exitTransition = { fadeOut(animationSpec = tween(250)) }
                ) {
                    composable(Screen.Splash.route) {
                        SplashScreen(
                            onSplashComplete = {
                                navController.navigate(Screen.Chat.createRoute()) {
                                    popUpTo(Screen.Splash.route) { inclusive = true }
                                }
                            }
                        )
                    }

                    composable(
                        route = Screen.Chat.route,
                        arguments = listOf(
                            navArgument("conversationId") {
                                type = NavType.StringType
                                nullable = true
                                defaultValue = null
                            }
                        )
                    ) { backStackEntry ->
                        val conversationId = backStackEntry.arguments?.getString("conversationId")
                        val chatViewModel: ChatViewModel = viewModel(
                            factory = ChatViewModel.provideFactory(appContainer)
                        )
                        ChatScreen(
                            viewModel = chatViewModel,
                            conversationIdParam = conversationId,
                            onNavigate = { route ->
                                if (route != Screen.Chat.route) {
                                    navController.navigate(route)
                                }
                            }
                        )
                    }

                    composable(Screen.Search.route) {
                        val searchViewModel: SearchViewModel = viewModel(
                            factory = SearchViewModel.provideFactory(appContainer)
                        )
                        SearchScreen(
                            viewModel = searchViewModel,
                            onNavigateBack = { navController.popBackStack() },
                            onNavigateToChat = { convId ->
                                navController.navigate(Screen.Chat.createRoute(convId)) {
                                    popUpTo(Screen.Chat.createRoute()) { inclusive = false }
                                }
                            }
                        )
                    }

                    composable(Screen.Studio.route) {
                        val studioViewModel: StudioViewModel = viewModel(
                            factory = StudioViewModel.provideFactory(appContainer)
                        )
                        StudioScreen(
                            viewModel = studioViewModel,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    composable(Screen.Memory.route) {
                        val memoryViewModel: MemoryViewModel = viewModel(
                            factory = MemoryViewModel.provideFactory(appContainer)
                        )
                        MemoryScreen(
                            viewModel = memoryViewModel,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    composable(Screen.Coding.route) {
                        val codingViewModel: CodingViewModel = viewModel(
                            factory = CodingViewModel.provideFactory(appContainer)
                        )
                        CodingScreen(
                            viewModel = codingViewModel,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    composable(Screen.Settings.route) {
                        val settingsViewModel: SettingsViewModel = viewModel(
                            factory = SettingsViewModel.provideFactory(appContainer)
                        )
                        SettingsScreen(
                            viewModel = settingsViewModel,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    composable(Screen.Profile.route) {
                        val profileViewModel: ProfileViewModel = viewModel(
                            factory = ProfileViewModel.provideFactory(appContainer)
                        )
                        ProfileScreen(
                            viewModel = profileViewModel,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }
}
