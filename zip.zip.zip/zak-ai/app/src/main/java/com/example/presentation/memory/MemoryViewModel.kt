package com.example.presentation.memory

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.common.AppContainer
import com.example.core.database.entity.MemoryEntity
import com.example.domain.repository.MemoryRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class MemoryUiState(
    val memories: List<MemoryEntity> = emptyList(),
    val isAddDialogOpen: Boolean = false,
    val editingMemory: MemoryEntity? = null,
    val isClearAllDialogOpen: Boolean = false
)

class MemoryViewModel(
    private val appContainer: AppContainer
) : ViewModel() {

    private val memoryRepository: MemoryRepository = appContainer.memoryRepository

    private val _uiState = MutableStateFlow(MemoryUiState())
    val uiState: StateFlow<MemoryUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            memoryRepository.getMemories().collect { mems ->
                _uiState.update { it.copy(memories = mems) }
            }
        }
    }

    fun openAddDialog() {
        _uiState.update { it.copy(isAddDialogOpen = true, editingMemory = null) }
    }

    fun openEditDialog(memory: MemoryEntity) {
        _uiState.update { it.copy(isAddDialogOpen = true, editingMemory = memory) }
    }

    fun closeDialog() {
        _uiState.update { it.copy(isAddDialogOpen = false, editingMemory = null) }
    }

    fun openClearAllDialog() {
        _uiState.update { it.copy(isClearAllDialogOpen = true) }
    }

    fun closeClearAllDialog() {
        _uiState.update { it.copy(isClearAllDialogOpen = false) }
    }

    fun saveMemory(title: String, content: String, category: String) {
        viewModelScope.launch {
            val editing = _uiState.value.editingMemory
            if (editing != null) {
                memoryRepository.updateMemory(editing.id, title, content, category)
            } else {
                memoryRepository.addMemory(title, content, category)
            }
            closeDialog()
        }
    }

    fun deleteMemory(id: Long) {
        viewModelScope.launch {
            memoryRepository.deleteMemory(id)
        }
    }

    fun clearAllMemories() {
        viewModelScope.launch {
            memoryRepository.clearAllMemories()
            closeClearAllDialog()
        }
    }

    companion object {
        fun provideFactory(container: AppContainer): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return MemoryViewModel(container) as T
                }
            }
    }
}
