package com.example.presentation.chat

import com.example.core.database.entity.ConversationEntity
import com.example.core.database.entity.MessageEntity
import com.example.core.model.AiModelConfig
import com.example.core.model.Attachment
import com.example.core.model.UsageState
import com.example.core.model.UserProfile

data class ChatUiState(
    val currentConversationId: String? = null,
    val currentConversationTitle: String = "New Chat",
    val messages: List<MessageEntity> = emptyList(),
    val recentConversations: List<ConversationEntity> = emptyList(),
    val inputText: String = "",
    val selectedAttachment: Attachment? = null,
    val usageState: UsageState = UsageState.READY,
    val isGenerating: Boolean = false,
    val isOnline: Boolean = true,
    val errorMessage: String? = null,
    val showVoiceSheet: Boolean = false,
    val markdownEnabled: Boolean = true,
    val autoScroll: Boolean = true,
    val enterToSend: Boolean = false,
    val selectedModel: AiModelConfig = AiModelConfig.GEMINI_FLASH,
    val userProfile: UserProfile = UserProfile()
)
