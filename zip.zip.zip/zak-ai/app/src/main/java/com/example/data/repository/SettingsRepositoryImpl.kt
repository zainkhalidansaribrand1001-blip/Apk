package com.example.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.core.model.AiModelConfig
import com.example.core.model.ThemeMode
import com.example.core.model.UserProfile
import com.example.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "zak_ai_settings")

class SettingsRepositoryImpl(
    private val context: Context
) : SettingsRepository {

    companion object {
        val KEY_THEME_MODE = stringPreferencesKey("theme_mode")
        val KEY_ENTER_TO_SEND = booleanPreferencesKey("enter_to_send")
        val KEY_AUTO_SCROLL = booleanPreferencesKey("auto_scroll")
        val KEY_MARKDOWN_ENABLED = booleanPreferencesKey("markdown_enabled")
        val KEY_SELECTED_MODEL_ID = stringPreferencesKey("selected_model_id")
        val KEY_STREAMING_ENABLED = booleanPreferencesKey("streaming_enabled")
        val KEY_BACKEND_URL = stringPreferencesKey("backend_url")
        val KEY_DEV_API_KEY = stringPreferencesKey("dev_api_key")

        val KEY_USER_NAME = stringPreferencesKey("user_name")
        val KEY_USER_TITLE = stringPreferencesKey("user_title")
        val KEY_USER_AVATAR_COLOR = stringPreferencesKey("user_avatar_color")
        val KEY_USER_CUSTOM_INSTRUCTIONS = stringPreferencesKey("user_custom_instructions")
    }

    override val themeModeFlow: Flow<ThemeMode> = context.dataStore.data.map { prefs ->
        val modeStr = prefs[KEY_THEME_MODE] ?: ThemeMode.DARK.name
        try {
            ThemeMode.valueOf(modeStr)
        } catch (_: Exception) {
            ThemeMode.DARK
        }
    }

    override val enterToSendFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_ENTER_TO_SEND] ?: false
    }

    override val autoScrollFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_AUTO_SCROLL] ?: true
    }

    override val markdownEnabledFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_MARKDOWN_ENABLED] ?: true
    }

    override val selectedModelFlow: Flow<AiModelConfig> = context.dataStore.data.map { prefs ->
        val modelId = prefs[KEY_SELECTED_MODEL_ID] ?: AiModelConfig.GEMINI_FLASH.id
        AiModelConfig.ALL_MODELS.find { it.id == modelId } ?: AiModelConfig.GEMINI_FLASH
    }

    override val streamingEnabledFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_STREAMING_ENABLED] ?: true
    }

    override val backendUrlFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_BACKEND_URL] ?: ""
    }

    override val devApiKeyFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_DEV_API_KEY] ?: ""
    }

    override val userProfileFlow: Flow<UserProfile> = context.dataStore.data.map { prefs ->
        UserProfile(
            name = prefs[KEY_USER_NAME] ?: "Alex Vance",
            title = prefs[KEY_USER_TITLE] ?: "AI Systems Engineer",
            avatarColorHex = prefs[KEY_USER_AVATAR_COLOR] ?: "#2563EB",
            customInstructions = prefs[KEY_USER_CUSTOM_INSTRUCTIONS] ?: ""
        )
    }

    override suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { prefs ->
            prefs[KEY_THEME_MODE] = mode.name
        }
    }

    override suspend fun setEnterToSend(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_ENTER_TO_SEND] = enabled
        }
    }

    override suspend fun setAutoScroll(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_AUTO_SCROLL] = enabled
        }
    }

    override suspend fun setMarkdownEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_MARKDOWN_ENABLED] = enabled
        }
    }

    override suspend fun setSelectedModel(modelConfig: AiModelConfig) {
        context.dataStore.edit { prefs ->
            prefs[KEY_SELECTED_MODEL_ID] = modelConfig.id
        }
    }

    override suspend fun setStreamingEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_STREAMING_ENABLED] = enabled
        }
    }

    override suspend fun setBackendUrl(url: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_BACKEND_URL] = url.trim()
        }
    }

    override suspend fun setDevApiKey(key: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_DEV_API_KEY] = key.trim()
        }
    }

    override suspend fun updateUserProfile(profile: UserProfile) {
        context.dataStore.edit { prefs ->
            prefs[KEY_USER_NAME] = profile.name.trim()
            prefs[KEY_USER_TITLE] = profile.title.trim()
            prefs[KEY_USER_AVATAR_COLOR] = profile.avatarColorHex.trim()
            prefs[KEY_USER_CUSTOM_INSTRUCTIONS] = profile.customInstructions.trim()
        }
    }

    override suspend fun resetAllData() {
        context.dataStore.edit { prefs ->
            prefs.clear()
        }
    }
}
