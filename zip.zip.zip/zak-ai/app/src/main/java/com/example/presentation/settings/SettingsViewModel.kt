package com.example.presentation.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.common.AppContainer
import com.example.core.model.AiModelConfig
import com.example.core.model.ThemeMode
import com.example.domain.repository.ChatRepository
import com.example.domain.repository.MemoryRepository
import com.example.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SettingsUiState(
    val themeMode: ThemeMode = ThemeMode.DARK,
    val enterToSend: Boolean = false,
    val autoScroll: Boolean = true,
    val markdownEnabled: Boolean = true,
    val selectedModel: AiModelConfig = AiModelConfig.GEMINI_FLASH,
    val streamingEnabled: Boolean = true,
    val backendUrl: String = "",
    val devApiKey: String = "",
    val isBackendConnected: Boolean = false,
    val isClearChatsDialogOpen: Boolean = false,
    val isClearMemoriesDialogOpen: Boolean = false,
    val isResetDialogOpen: Boolean = false,
    val successToast: String? = null
)

class SettingsViewModel(
    private val appContainer: AppContainer
) : ViewModel() {

    private val settingsRepository: SettingsRepository = appContainer.settingsRepository
    private val chatRepository: ChatRepository = appContainer.chatRepository
    private val memoryRepository: MemoryRepository = appContainer.memoryRepository
    private val aiService = appContainer.aiService

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    init {
        settingsRepository.themeModeFlow
            .onEach { mode -> _uiState.update { it.copy(themeMode = mode) } }
            .launchIn(viewModelScope)

        settingsRepository.enterToSendFlow
            .onEach { ets -> _uiState.update { it.copy(enterToSend = ets) } }
            .launchIn(viewModelScope)

        settingsRepository.autoScrollFlow
            .onEach { ascr -> _uiState.update { it.copy(autoScroll = ascr) } }
            .launchIn(viewModelScope)

        settingsRepository.markdownEnabledFlow
            .onEach { md -> _uiState.update { it.copy(markdownEnabled = md) } }
            .launchIn(viewModelScope)

        settingsRepository.selectedModelFlow
            .onEach { model -> _uiState.update { it.copy(selectedModel = model) } }
            .launchIn(viewModelScope)

        settingsRepository.streamingEnabledFlow
            .onEach { stream -> _uiState.update { it.copy(streamingEnabled = stream) } }
            .launchIn(viewModelScope)

        settingsRepository.backendUrlFlow
            .onEach { url -> _uiState.update { it.copy(backendUrl = url) } }
            .launchIn(viewModelScope)

        settingsRepository.devApiKeyFlow
            .onEach { key -> _uiState.update { it.copy(devApiKey = key) } }
            .launchIn(viewModelScope)

        viewModelScope.launch {
            val connected = aiService.isBackendConnected()
            _uiState.update { it.copy(isBackendConnected = connected) }
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            settingsRepository.setThemeMode(mode)
        }
    }

    fun setEnterToSend(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.setEnterToSend(enabled)
        }
    }

    fun setAutoScroll(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.setAutoScroll(enabled)
        }
    }

    fun setMarkdownEnabled(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.setMarkdownEnabled(enabled)
        }
    }

    fun setSelectedModel(model: AiModelConfig) {
        viewModelScope.launch {
            settingsRepository.setSelectedModel(model)
        }
    }

    fun setStreamingEnabled(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.setStreamingEnabled(enabled)
        }
    }

    fun setBackendUrl(url: String) {
        viewModelScope.launch {
            settingsRepository.setBackendUrl(url)
            val connected = aiService.isBackendConnected()
            _uiState.update { it.copy(isBackendConnected = connected) }
        }
    }

    fun setDevApiKey(key: String) {
        viewModelScope.launch {
            settingsRepository.setDevApiKey(key)
            val connected = aiService.isBackendConnected()
            _uiState.update { it.copy(isBackendConnected = connected) }
        }
    }

    fun openClearChatsDialog() = _uiState.update { it.copy(isClearChatsDialogOpen = true) }
    fun closeClearChatsDialog() = _uiState.update { it.copy(isClearChatsDialogOpen = false) }

    fun openClearMemoriesDialog() = _uiState.update { it.copy(isClearMemoriesDialogOpen = true) }
    fun closeClearMemoriesDialog() = _uiState.update { it.copy(isClearMemoriesDialogOpen = false) }

    fun openResetDialog() = _uiState.update { it.copy(isResetDialogOpen = true) }
    fun closeResetDialog() = _uiState.update { it.copy(isResetDialogOpen = false) }

    fun clearAllChats() {
        viewModelScope.launch {
            chatRepository.clearAllConversations()
            closeClearChatsDialog()
            _uiState.update { it.copy(successToast = "All chat history cleared") }
        }
    }

    fun clearAllMemories() {
        viewModelScope.launch {
            memoryRepository.clearAllMemories()
            closeClearMemoriesDialog()
            _uiState.update { it.copy(successToast = "All memories cleared") }
        }
    }

    fun resetAllAppData() {
        viewModelScope.launch {
            chatRepository.clearAllConversations()
            memoryRepository.clearAllMemories()
            settingsRepository.resetAllData()
            closeResetDialog()
            _uiState.update { it.copy(successToast = "Application data reset to defaults") }
        }
    }

    fun clearToast() = _uiState.update { it.copy(successToast = null) }

    companion object {
        fun provideFactory(container: AppContainer): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return SettingsViewModel(container) as T
                }
            }
    }
}
