package com.example.presentation.studio

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.common.AppContainer
import com.example.core.model.AiModelConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class StudioTab {
    CODE_SYNTHESIS,
    TEXT_STUDIO,
    IMAGE_STUDIO
}

data class StudioUiState(
    val activeTab: StudioTab = StudioTab.CODE_SYNTHESIS,
    // Code Synthesis
    val codePrompt: String = "",
    val codeLanguage: String = "Kotlin",
    val generatedCode: String = "",
    val isGeneratingCode: Boolean = false,
    val codeError: String? = null,
    // Text Studio
    val textPrompt: String = "",
    val textTone: String = "Concise & Executive",
    val generatedText: String = "",
    val isGeneratingText: Boolean = false,
    val textError: String? = null,
    // Image Studio
    val imagePrompt: String = "",
    val selectedAspectRatio: String = "1:1",
    val selectedStyle: String = "Photorealistic Cybernetic",
    val isImageSubmitting: Boolean = false,
    val imageStatusMessage: String? = null
)

class StudioViewModel(
    private val appContainer: AppContainer
) : ViewModel() {

    private val aiService = appContainer.aiService
    private val settingsRepository = appContainer.settingsRepository

    private val _uiState = MutableStateFlow(StudioUiState())
    val uiState: StateFlow<StudioUiState> = _uiState.asStateFlow()

    fun setTab(tab: StudioTab) {
        _uiState.update { it.copy(activeTab = tab) }
    }

    fun onCodePromptChanged(text: String) {
        _uiState.update { it.copy(codePrompt = text) }
    }

    fun onCodeLanguageChanged(lang: String) {
        _uiState.update { it.copy(codeLanguage = lang) }
    }

    fun generateCode() {
        val prompt = _uiState.value.codePrompt.trim()
        if (prompt.isEmpty() || _uiState.value.isGeneratingCode) return

        viewModelScope.launch {
            _uiState.update { it.copy(isGeneratingCode = true, codeError = null, generatedCode = "") }
            val fullPrompt = "Write clean, production-ready ${_uiState.value.codeLanguage} code for the following task:\n$prompt\n\nProvide the code along with brief explanation."
            val model = settingsRepository.selectedModelFlow.firstOrNull() ?: AiModelConfig.GEMINI_FLASH

            val result = aiService.generateResponse(
                prompt = fullPrompt,
                history = emptyList(),
                modelConfig = model,
                systemPrompt = "You are the ZAK AI Code Synthesis Engine. Provide pristine, idiomatic, commented code."
            )

            result.onSuccess { codeOutput ->
                _uiState.update { it.copy(generatedCode = codeOutput, isGeneratingCode = false) }
            }.onFailure { error ->
                _uiState.update {
                    it.copy(
                        codeError = error.message ?: "ZAK AI couldn't connect right now. Please try again in a moment.",
                        isGeneratingCode = false
                    )
                }
            }
        }
    }

    fun onTextPromptChanged(text: String) {
        _uiState.update { it.copy(textPrompt = text) }
    }

    fun onTextToneChanged(tone: String) {
        _uiState.update { it.copy(textTone = tone) }
    }

    fun generateText() {
        val prompt = _uiState.value.textPrompt.trim()
        if (prompt.isEmpty() || _uiState.value.isGeneratingText) return

        viewModelScope.launch {
            _uiState.update { it.copy(isGeneratingText = true, textError = null, generatedText = "") }
            val fullPrompt = "In a ${_uiState.value.textTone} tone, draft the following:\n$prompt"
            val model = settingsRepository.selectedModelFlow.firstOrNull() ?: AiModelConfig.GEMINI_FLASH

            val result = aiService.generateResponse(
                prompt = fullPrompt,
                history = emptyList(),
                modelConfig = model,
                systemPrompt = "You are the ZAK AI Text Studio. Provide articulate, polished copy."
            )

            result.onSuccess { textOutput ->
                _uiState.update { it.copy(generatedText = textOutput, isGeneratingText = false) }
            }.onFailure { error ->
                _uiState.update {
                    it.copy(
                        textError = error.message ?: "ZAK AI couldn't connect right now. Please try again in a moment.",
                        isGeneratingText = false
                    )
                }
            }
        }
    }

    fun onImagePromptChanged(prompt: String) {
        _uiState.update { it.copy(imagePrompt = prompt) }
    }

    fun onAspectRatioChanged(ratio: String) {
        _uiState.update { it.copy(selectedAspectRatio = ratio) }
    }

    fun onImageStyleChanged(style: String) {
        _uiState.update { it.copy(selectedStyle = style) }
    }

    fun submitImageRequest() {
        val prompt = _uiState.value.imagePrompt.trim()
        if (prompt.isEmpty()) return

        _uiState.update {
            it.copy(
                isImageSubmitting = true,
                imageStatusMessage = "Synthesizing image generation parameters for '${prompt.take(24)}...' with style '${it.selectedStyle}' [Aspect: ${it.selectedAspectRatio}]. Awaiting upstream Image Generation API gateway deployment."
            )
        }
    }

    companion object {
        fun provideFactory(container: AppContainer): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return StudioViewModel(container) as T
                }
            }
    }
}
