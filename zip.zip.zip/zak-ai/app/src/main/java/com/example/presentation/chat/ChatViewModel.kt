package com.example.presentation.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.common.AppContainer
import com.example.core.model.Attachment
import com.example.core.model.UsageState
import com.example.domain.repository.ChatRepository
import com.example.domain.repository.MemoryRepository
import com.example.domain.repository.SettingsRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class ChatViewModel(
    private val appContainer: AppContainer
) : ViewModel() {

    private val chatRepository: ChatRepository = appContainer.chatRepository
    private val memoryRepository: MemoryRepository = appContainer.memoryRepository
    private val settingsRepository: SettingsRepository = appContainer.settingsRepository
    private val aiService = appContainer.aiService
    private val networkMonitor = appContainer.networkMonitor

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    private var messageObservationJob: Job? = null
    private var generationJob: Job? = null

    init {
        // Observe recent conversations
        chatRepository.getConversations()
            .onEach { convs ->
                _uiState.update { it.copy(recentConversations = convs) }
            }
            .launchIn(viewModelScope)

        // Observe network state
        networkMonitor.isOnline
            .onEach { online ->
                _uiState.update { current ->
                    current.copy(
                        isOnline = online,
                        usageState = if (!online) UsageState.OFFLINE else if (current.isGenerating) UsageState.PROCESSING else UsageState.READY
                    )
                }
            }
            .launchIn(viewModelScope)

        // Observe Settings
        settingsRepository.selectedModelFlow
            .onEach { model -> _uiState.update { it.copy(selectedModel = model) } }
            .launchIn(viewModelScope)

        settingsRepository.markdownEnabledFlow
            .onEach { md -> _uiState.update { it.copy(markdownEnabled = md) } }
            .launchIn(viewModelScope)

        settingsRepository.autoScrollFlow
            .onEach { ascr -> _uiState.update { it.copy(autoScroll = ascr) } }
            .launchIn(viewModelScope)

        settingsRepository.enterToSendFlow
            .onEach { ets -> _uiState.update { it.copy(enterToSend = ets) } }
            .launchIn(viewModelScope)

        settingsRepository.userProfileFlow
            .onEach { profile -> _uiState.update { it.copy(userProfile = profile) } }
            .launchIn(viewModelScope)
    }

    fun selectConversation(conversationId: String?) {
        if (conversationId == _uiState.value.currentConversationId) return

        messageObservationJob?.cancel()
        _uiState.update {
            it.copy(
                currentConversationId = conversationId,
                currentConversationTitle = if (conversationId == null) "New Chat" else it.currentConversationTitle,
                messages = emptyList(),
                errorMessage = null
            )
        }

        if (conversationId != null) {
            viewModelScope.launch {
                val conv = chatRepository.getConversationById(conversationId)
                if (conv != null) {
                    _uiState.update { it.copy(currentConversationTitle = conv.title) }
                }
            }
            messageObservationJob = chatRepository.getMessages(conversationId)
                .onEach { msgs ->
                    _uiState.update { it.copy(messages = msgs) }
                }
                .launchIn(viewModelScope)
        }
    }

    fun startNewChat() {
        cancelGeneration()
        selectConversation(null)
    }

    fun onInputTextChanged(newText: String) {
        _uiState.update { it.copy(inputText = newText) }
    }

    fun onAttachmentSelected(attachment: Attachment?) {
        _uiState.update { it.copy(selectedAttachment = attachment) }
    }

    fun setVoiceSheetVisible(visible: Boolean) {
        _uiState.update { it.copy(showVoiceSheet = visible) }
    }

    fun clearErrorMessage() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    fun deleteConversation(id: String) {
        viewModelScope.launch {
            chatRepository.deleteConversation(id)
            if (_uiState.value.currentConversationId == id) {
                startNewChat()
            }
        }
    }

    fun sendMessage(promptOverride: String? = null) {
        val prompt = (promptOverride ?: _uiState.value.inputText).trim()
        val attachment = _uiState.value.selectedAttachment

        if (prompt.isEmpty() && attachment == null) return
        if (_uiState.value.isGenerating) return

        if (!_uiState.value.isOnline) {
            _uiState.update {
                it.copy(
                    usageState = UsageState.OFFLINE,
                    errorMessage = "ZAK AI is offline. Please check your network connection."
                )
            }
            return
        }

        // Clear input bar
        _uiState.update {
            it.copy(
                inputText = "",
                selectedAttachment = null,
                isGenerating = true,
                usageState = UsageState.PROCESSING,
                errorMessage = null
            )
        }

        generationJob = viewModelScope.launch {
            try {
                // Ensure conversation exists
                var convId = _uiState.value.currentConversationId
                if (convId == null) {
                    val newConv = chatRepository.createConversation(prompt)
                    convId = newConv.id
                    _uiState.update {
                        it.copy(
                            currentConversationId = convId,
                            currentConversationTitle = newConv.title
                        )
                    }
                    // Start observing messages for this new conversation
                    messageObservationJob = chatRepository.getMessages(convId)
                        .onEach { msgs -> _uiState.update { it.copy(messages = msgs) } }
                        .launchIn(viewModelScope)
                }

                // Save user message to database
                chatRepository.saveUserMessage(convId, prompt, attachment)

                // Retrieve memory context to inject into AI system prompt
                val memories = memoryRepository.getMemories().firstOrNull() ?: emptyList()
                val memoryContext = if (memories.isNotEmpty()) {
                    "User Memory Directives:\n" + memories.joinToString("\n") { "- ${it.title}: ${it.content}" }
                } else null

                val profileInstructions = _uiState.value.userProfile.customInstructions
                val combinedSystemPrompt = listOfNotNull(
                    memoryContext,
                    profileInstructions.ifBlank { null }
                ).joinToString("\n\n").ifBlank { null }

                val currentHistory = chatRepository.getMessages(convId).firstOrNull() ?: emptyList()
                val streamingEnabled = settingsRepository.streamingEnabledFlow.firstOrNull() ?: true

                if (streamingEnabled) {
                    // Create initial AI placeholder message in DB
                    val initialAiMessage = chatRepository.saveAiMessage(convId, "")
                    val aiMessageId = initialAiMessage.id
                    val accumulatedText = StringBuilder()

                    aiService.streamResponse(
                        prompt = prompt,
                        history = currentHistory,
                        modelConfig = _uiState.value.selectedModel,
                        systemPrompt = combinedSystemPrompt,
                        attachment = attachment
                    )
                        .catch { e ->
                            val friendlyMsg = e.message ?: "ZAK AI couldn't connect right now. Please try again in a moment."
                            val errorContent = if (accumulatedText.isNotEmpty()) {
                                accumulatedText.toString() + "\n\n*[Connection interrupted]*"
                            } else {
                                friendlyMsg
                            }
                            chatRepository.updateMessage(aiMessageId, convId, errorContent)
                            _uiState.update {
                                it.copy(
                                    isGenerating = false,
                                    usageState = if (friendlyMsg.contains("usage limit")) UsageState.RATE_LIMITED else UsageState.READY,
                                    errorMessage = friendlyMsg
                                )
                            }
                        }
                        .collect { chunk ->
                            accumulatedText.append(chunk)
                            chatRepository.updateMessage(aiMessageId, convId, accumulatedText.toString())
                        }

                    _uiState.update {
                        it.copy(
                            isGenerating = false,
                            usageState = UsageState.READY
                        )
                    }
                } else {
                    val result = aiService.generateResponse(
                        prompt = prompt,
                        history = currentHistory,
                        modelConfig = _uiState.value.selectedModel,
                        systemPrompt = combinedSystemPrompt,
                        attachment = attachment
                    )

                    result.onSuccess { reply ->
                        chatRepository.saveAiMessage(convId, reply)
                        _uiState.update {
                            it.copy(
                                isGenerating = false,
                                usageState = UsageState.READY
                            )
                        }
                    }.onFailure { error ->
                        val friendlyMsg = error.message ?: "ZAK AI couldn't connect right now. Please try again in a moment."
                        chatRepository.saveAiMessage(convId, friendlyMsg)
                        _uiState.update {
                            it.copy(
                                isGenerating = false,
                                usageState = if (friendlyMsg.contains("usage limit")) UsageState.RATE_LIMITED else UsageState.READY,
                                errorMessage = friendlyMsg
                            )
                        }
                    }
                }

            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isGenerating = false,
                        usageState = UsageState.ERROR,
                        errorMessage = "ZAK AI couldn't connect right now. Please try again in a moment."
                    )
                }
            }
        }
    }

    fun cancelGeneration() {
        if (_uiState.value.isGenerating) {
            generationJob?.cancel()
            _uiState.update {
                it.copy(
                    isGenerating = false,
                    usageState = UsageState.READY
                )
            }
        }
    }

    companion object {
        fun provideFactory(container: AppContainer): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return ChatViewModel(container) as T
                }
            }
    }
}
