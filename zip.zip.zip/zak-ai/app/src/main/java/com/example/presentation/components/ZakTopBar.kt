package com.example.presentation.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.UsageState
import com.example.ui.theme.ZakElectricBlue
import com.example.ui.theme.ZakError
import com.example.ui.theme.ZakLuminousCyan
import com.example.ui.theme.ZakSubtleCyan
import com.example.ui.theme.ZakSuccess
import com.example.ui.theme.ZakWarning

@Composable
fun ZakTopBar(
    usageState: UsageState,
    activeChatTitle: String? = null,
    onMenuClick: () -> Unit,
    onNewChatClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val statusColor by animateColorAsState(
        targetValue = when (usageState) {
            UsageState.READY -> ZakSuccess
            UsageState.PROCESSING -> ZakSubtleCyan
            UsageState.RATE_LIMITED -> ZakWarning
            UsageState.OFFLINE -> Color(0xFF94A3B8)
            UsageState.ERROR -> ZakError
        },
        animationSpec = tween(300),
        label = "status_color"
    )

    val statusText = when (usageState) {
        UsageState.READY -> "Ready"
        UsageState.PROCESSING -> "Processing"
        UsageState.RATE_LIMITED -> "Rate Limited"
        UsageState.OFFLINE -> "Offline"
        UsageState.ERROR -> "Service Alert"
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left: Hamburger Menu
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = onMenuClick,
                modifier = Modifier.size(44.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = "Open Navigation Menu",
                    tint = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Brand / Title Area
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ZakLogo(
                        size = 22.dp,
                        isPulsing = usageState == UsageState.PROCESSING
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ZAK AI",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )
                }

                if (!activeChatTitle.isNullOrBlank() && activeChatTitle != "New Chat") {
                    Text(
                        text = activeChatTitle,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp
                        ),
                        maxLines = 1,
                        modifier = Modifier.width(180.dp)
                    )
                }
            }
        }

        // Right: Status indicator pill + New Chat action
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Status Pill
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f))
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(7.dp)
                        .background(statusColor, CircleShape)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = statusText,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
            }

            // New Chat shortcut icon
            IconButton(
                onClick = onNewChatClick,
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(ZakElectricBlue.copy(alpha = 0.15f))
                    .border(1.dp, ZakElectricBlue.copy(alpha = 0.3f), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Start New Chat",
                    tint = ZakLuminousCyan,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
