package com.example

import android.app.Application
import com.example.core.common.AppContainer
import com.example.core.common.DefaultAppContainer

class ZakAiApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = DefaultAppContainer(this)
    }
}
