package com.example.presentation.coding

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.common.AppContainer
import com.example.core.model.AiModelConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class CodingAction {
    EXPLAIN,
    OPTIMIZE,
    DEBUG
}

data class CodingUiState(
    val codeInput: String = "",
    val selectedLanguage: String = "Kotlin",
    val isAnalyzing: Boolean = false,
    val analysisResult: String = "",
    val errorMessage: String? = null
)

class CodingViewModel(
    private val appContainer: AppContainer
) : ViewModel() {

    private val aiService = appContainer.aiService
    private val settingsRepository = appContainer.settingsRepository

    private val _uiState = MutableStateFlow(CodingUiState())
    val uiState: StateFlow<CodingUiState> = _uiState.asStateFlow()

    fun onCodeChanged(code: String) {
        _uiState.update { it.copy(codeInput = code) }
    }

    fun onLanguageSelected(lang: String) {
        _uiState.update { it.copy(selectedLanguage = lang) }
    }

    fun clearCode() {
        _uiState.update { it.copy(codeInput = "", analysisResult = "", errorMessage = null) }
    }

    fun runCodingAction(action: CodingAction) {
        val code = _uiState.value.codeInput.trim()
        if (code.isEmpty() || _uiState.value.isAnalyzing) return

        val lang = _uiState.value.selectedLanguage
        val prompt = when (action) {
            CodingAction.EXPLAIN -> "Explain this $lang code concisely, detailing logic flow, key operations, and edge cases:\n```$lang\n$code\n```"
            CodingAction.OPTIMIZE -> "Refactor and optimize this $lang code for performance, safety, and modern idioms. Provide the improved code and rationale:\n```$lang\n$code\n```"
            CodingAction.DEBUG -> "Analyze this $lang code for potential bugs, memory leaks, concurrency issues, or syntax errors. Explain how to fix them:\n```$lang\n$code\n```"
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isAnalyzing = true, errorMessage = null, analysisResult = "") }
            val model = settingsRepository.selectedModelFlow.firstOrNull() ?: AiModelConfig.GEMINI_FLASH

            val result = aiService.generateResponse(
                prompt = prompt,
                history = emptyList(),
                modelConfig = model,
                systemPrompt = "You are the ZAK AI Coding Evolution Engine. You specialize in deep software engineering, debugging, and code optimization."
            )

            result.onSuccess { output ->
                _uiState.update { it.copy(analysisResult = output, isAnalyzing = false) }
            }.onFailure { error ->
                _uiState.update {
                    it.copy(
                        errorMessage = error.message ?: "ZAK AI couldn't connect right now. Please try again in a moment.",
                        isAnalyzing = false
                    )
                }
            }
        }
    }

    companion object {
        fun provideFactory(container: AppContainer): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return CodingViewModel(container) as T
                }
            }
    }
}
