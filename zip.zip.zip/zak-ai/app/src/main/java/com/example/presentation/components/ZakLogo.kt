package com.example.presentation.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.ZakElectricBlue
import com.example.ui.theme.ZakLuminousCyan
import com.example.ui.theme.ZakSubtleCyan

@Composable
fun ZakLogo(
    modifier: Modifier = Modifier,
    size: Dp = 40.dp,
    monochrome: Boolean = false,
    tint: Color? = null,
    isPulsing: Boolean = false
) {
    val primaryColor = tint ?: if (monochrome) MaterialTheme.colorScheme.onSurface else ZakElectricBlue
    val secondaryColor = tint ?: if (monochrome) MaterialTheme.colorScheme.onSurface else ZakSubtleCyan
    val accentSpark = tint ?: if (monochrome) MaterialTheme.colorScheme.onSurface else ZakLuminousCyan

    val infiniteTransition = rememberInfiniteTransition(label = "logo_pulse")
    val alphaGlow by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.6f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha_glow"
    )

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val w = this.size.width
            val h = this.size.height

            // Outer subtle hexagon border
            val hexPath = Path().apply {
                moveTo(w * 0.5f, h * 0.05f)
                lineTo(w * 0.88f, h * 0.27f)
                lineTo(w * 0.88f, h * 0.73f)
                lineTo(w * 0.5f, h * 0.95f)
                lineTo(w * 0.12f, h * 0.73f)
                lineTo(w * 0.12f, h * 0.27f)
                close()
            }

            if (isPulsing) {
                drawPath(
                    path = hexPath,
                    color = secondaryColor.copy(alpha = alphaGlow),
                    style = Stroke(width = w * 0.05f)
                )
            } else {
                drawPath(
                    path = hexPath,
                    color = primaryColor.copy(alpha = 0.35f),
                    style = Stroke(width = w * 0.035f)
                )
            }

            // Top horizontal bar of Z
            val topBarPath = Path().apply {
                moveTo(w * 0.26f, h * 0.30f)
                lineTo(w * 0.74f, h * 0.30f)
                lineTo(w * 0.67f, h * 0.40f)
                lineTo(w * 0.33f, h * 0.40f)
                close()
            }
            drawPath(
                path = topBarPath,
                brush = Brush.horizontalGradient(listOf(secondaryColor, primaryColor))
            )

            // Center diagonal slash with cybernetic bevel
            val diagonalPath = Path().apply {
                moveTo(w * 0.70f, h * 0.39f)
                lineTo(w * 0.34f, h * 0.64f)
                lineTo(w * 0.43f, h * 0.64f)
                lineTo(w * 0.77f, h * 0.39f)
                close()
            }
            drawPath(
                path = diagonalPath,
                brush = Brush.linearGradient(
                    colors = listOf(primaryColor, secondaryColor),
                    start = Offset(w * 0.34f, h * 0.64f),
                    end = Offset(w * 0.77f, h * 0.39f)
                )
            )

            // Bottom horizontal bar of Z
            val bottomBarPath = Path().apply {
                moveTo(w * 0.26f, h * 0.70f)
                lineTo(w * 0.66f, h * 0.70f)
                lineTo(w * 0.74f, h * 0.60f)
                lineTo(w * 0.33f, h * 0.60f)
                close()
            }
            drawPath(
                path = bottomBarPath,
                brush = Brush.horizontalGradient(listOf(primaryColor, secondaryColor))
            )

            // Central spark / diamond core
            val sparkPath = Path().apply {
                val cx = w * 0.5f
                val cy = h * 0.5f
                val r = w * 0.055f
                moveTo(cx, cy - r)
                lineTo(cx + r, cy)
                lineTo(cx, cy + r)
                lineTo(cx - r, cy)
                close()
            }
            drawPath(
                path = sparkPath,
                color = accentSpark
            )
        }
    }
}
