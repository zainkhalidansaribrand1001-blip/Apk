package com.example.presentation.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.common.AppContainer
import com.example.domain.repository.ChatRepository
import com.example.domain.repository.SearchMatch
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SearchUiState(
    val query: String = "",
    val isLoading: Boolean = false,
    val results: List<SearchMatch> = emptyList(),
    val hasSearched: Boolean = false
)

class SearchViewModel(
    private val appContainer: AppContainer
) : ViewModel() {

    private val chatRepository: ChatRepository = appContainer.chatRepository

    private val _uiState = MutableStateFlow(SearchUiState())
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    private var searchJob: Job? = null

    fun onQueryChanged(newQuery: String) {
        _uiState.update { it.copy(query = newQuery) }
        searchJob?.cancel()

        if (newQuery.trim().isEmpty()) {
            _uiState.update { it.copy(results = emptyList(), hasSearched = false, isLoading = false) }
            return
        }

        searchJob = viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            delay(250) // debounce
            val matches = chatRepository.search(newQuery)
            _uiState.update {
                it.copy(
                    results = matches,
                    isLoading = false,
                    hasSearched = true
                )
            }
        }
    }

    fun clearQuery() {
        searchJob?.cancel()
        _uiState.update { SearchUiState() }
    }

    companion object {
        fun provideFactory(container: AppContainer): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return SearchViewModel(container) as T
                }
            }
    }
}
