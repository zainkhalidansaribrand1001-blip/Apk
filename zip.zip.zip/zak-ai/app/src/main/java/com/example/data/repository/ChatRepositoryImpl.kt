package com.example.data.repository

import com.example.core.database.dao.ConversationDao
import com.example.core.database.dao.MessageDao
import com.example.core.database.entity.ConversationEntity
import com.example.core.database.entity.MessageEntity
import com.example.core.model.Attachment
import com.example.domain.repository.ChatRepository
import com.example.domain.repository.SearchMatch
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class ChatRepositoryImpl(
    private val conversationDao: ConversationDao,
    private val messageDao: MessageDao
) : ChatRepository {

    override fun getConversations(): Flow<List<ConversationEntity>> {
        return conversationDao.getAllConversations()
    }

    override fun getMessages(conversationId: String): Flow<List<MessageEntity>> {
        return messageDao.getMessagesForConversation(conversationId)
    }

    override suspend fun getConversationById(id: String): ConversationEntity? {
        return conversationDao.getConversationByIdOnce(id)
    }

    override suspend fun createConversation(firstMessage: String): ConversationEntity {
        val id = UUID.randomUUID().toString()
        val title = generateConversationTitle(firstMessage)
        val now = System.currentTimeMillis()
        val conversation = ConversationEntity(
            id = id,
            title = title,
            createdAt = now,
            updatedAt = now
        )
        conversationDao.insertConversation(conversation)
        return conversation
    }

    override suspend fun saveUserMessage(
        conversationId: String,
        content: String,
        attachment: Attachment?
    ): MessageEntity {
        val now = System.currentTimeMillis()
        val message = MessageEntity(
            id = UUID.randomUUID().toString(),
            conversationId = conversationId,
            role = "USER",
            content = content,
            timestamp = now,
            attachmentUri = attachment?.uriString,
            attachmentName = attachment?.displayName
        )
        messageDao.insertMessage(message)
        conversationDao.touchConversation(conversationId, now)
        return message
    }

    override suspend fun saveAiMessage(
        conversationId: String,
        content: String
    ): MessageEntity {
        val now = System.currentTimeMillis()
        val message = MessageEntity(
            id = UUID.randomUUID().toString(),
            conversationId = conversationId,
            role = "AI",
            content = content,
            timestamp = now
        )
        messageDao.insertMessage(message)
        conversationDao.touchConversation(conversationId, now)
        return message
    }

    override suspend fun updateMessage(messageId: String, conversationId: String, content: String) {
        val message = MessageEntity(
            id = messageId,
            conversationId = conversationId,
            role = "AI",
            content = content,
            timestamp = System.currentTimeMillis()
        )
        messageDao.insertMessage(message)
        conversationDao.touchConversation(conversationId, System.currentTimeMillis())
    }

    override suspend fun deleteConversation(conversationId: String) {
        conversationDao.deleteConversation(conversationId)
        messageDao.deleteMessagesForConversation(conversationId)
    }

    override suspend fun clearAllConversations() {
        messageDao.deleteAllMessages()
        conversationDao.deleteAllConversations()
    }

    override suspend fun search(query: String): List<SearchMatch> {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return emptyList()

        val matchingConversations = conversationDao.searchConversations(trimmed)
        val matchingMessages = messageDao.searchMessages(trimmed)

        val resultMap = LinkedHashMap<String, SearchMatch>()

        for (conv in matchingConversations) {
            resultMap[conv.id] = SearchMatch(
                conversation = conv,
                matchedMessageSnippet = null,
                timestamp = conv.updatedAt
            )
        }

        for (msg in matchingMessages) {
            val conv = conversationDao.getConversationByIdOnce(msg.conversationId)
            if (conv != null && !resultMap.containsKey(conv.id)) {
                val snippet = extractSnippet(msg.content, trimmed)
                resultMap[conv.id] = SearchMatch(
                    conversation = conv,
                    matchedMessageSnippet = snippet,
                    timestamp = msg.timestamp
                )
            }
        }

        return resultMap.values.sortedByDescending { it.timestamp }
    }

    private fun extractSnippet(fullText: String, query: String): String {
        val index = fullText.indexOf(query, ignoreCase = true)
        if (index == -1) return fullText.take(120)

        val start = (index - 30).coerceAtLeast(0)
        val end = (index + query.length + 50).coerceAtMost(fullText.length)
        val prefix = if (start > 0) "..." else ""
        val suffix = if (end < fullText.length) "..." else ""
        return prefix + fullText.substring(start, end).replace("\n", " ").trim() + suffix
    }

    override fun generateConversationTitle(prompt: String): String {
        var clean = prompt.trim()
        val removePrefixes = listOf(
            "explain to me", "explain", "how do i", "how to", "can you tell me",
            "can you", "what is the", "what is", "tell me about", "help me with",
            "write code for", "write a", "write", "create a", "create", "please"
        )
        for (prefix in removePrefixes) {
            if (clean.startsWith(prefix, ignoreCase = true)) {
                clean = clean.substring(prefix.length).trim()
                break
            }
        }

        if (clean.length > 38) {
            val words = clean.split(" ")
            val sb = StringBuilder()
            for (w in words) {
                if (sb.length + w.length + 1 > 35) break
                if (sb.isNotEmpty()) sb.append(" ")
                sb.append(w)
            }
            clean = sb.toString()
        }

        if (clean.isBlank()) clean = "New Conversation"

        return clean.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
    }
}
