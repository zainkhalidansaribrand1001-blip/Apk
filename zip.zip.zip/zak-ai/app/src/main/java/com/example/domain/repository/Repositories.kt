package com.example.domain.repository

import com.example.core.database.entity.ConversationEntity
import com.example.core.database.entity.MemoryEntity
import com.example.core.database.entity.MessageEntity
import com.example.core.model.AiModelConfig
import com.example.core.model.Attachment
import com.example.core.model.ThemeMode
import com.example.core.model.UserProfile
import kotlinx.coroutines.flow.Flow

data class SearchMatch(
    val conversation: ConversationEntity,
    val matchedMessageSnippet: String?,
    val timestamp: Long
)

interface ChatRepository {
    fun getConversations(): Flow<List<ConversationEntity>>
    fun getMessages(conversationId: String): Flow<List<MessageEntity>>
    suspend fun getConversationById(id: String): ConversationEntity?
    suspend fun createConversation(firstMessage: String): ConversationEntity
    suspend fun saveUserMessage(
        conversationId: String,
        content: String,
        attachment: Attachment? = null
    ): MessageEntity
    suspend fun saveAiMessage(
        conversationId: String,
        content: String
    ): MessageEntity
    suspend fun updateMessage(messageId: String, conversationId: String, content: String)
    suspend fun deleteConversation(conversationId: String)
    suspend fun clearAllConversations()
    suspend fun search(query: String): List<SearchMatch>
    fun generateConversationTitle(prompt: String): String
}

interface MemoryRepository {
    fun getMemories(): Flow<List<MemoryEntity>>
    suspend fun addMemory(title: String, content: String, category: String = "General"): Long
    suspend fun updateMemory(id: Long, title: String, content: String, category: String)
    suspend fun deleteMemory(id: Long)
    suspend fun clearAllMemories()
}

interface SettingsRepository {
    val themeModeFlow: Flow<ThemeMode>
    val enterToSendFlow: Flow<Boolean>
    val autoScrollFlow: Flow<Boolean>
    val markdownEnabledFlow: Flow<Boolean>
    val selectedModelFlow: Flow<AiModelConfig>
    val streamingEnabledFlow: Flow<Boolean>
    val backendUrlFlow: Flow<String>
    val devApiKeyFlow: Flow<String>
    val userProfileFlow: Flow<UserProfile>

    suspend fun setThemeMode(mode: ThemeMode)
    suspend fun setEnterToSend(enabled: Boolean)
    suspend fun setAutoScroll(enabled: Boolean)
    suspend fun setMarkdownEnabled(enabled: Boolean)
    suspend fun setSelectedModel(modelConfig: AiModelConfig)
    suspend fun setStreamingEnabled(enabled: Boolean)
    suspend fun setBackendUrl(url: String)
    suspend fun setDevApiKey(key: String)
    suspend fun updateUserProfile(profile: UserProfile)
    suspend fun resetAllData()
}
