package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ZAK AI Dark Brand Palette (Deep Charcoal + Electric Blue + Subtle Cyan + Glass Surfaces)
val ZakDeepCharcoal = Color(0xFF090D16)
val ZakSurfaceDark = Color(0xFF101726)
val ZakSurfaceVariantDark = Color(0xFF162136)
val ZakSurfaceElevatedDark = Color(0xFF1B2842)
val ZakBorderDark = Color(0xFF223250)
val ZakBorderSubtleDark = Color(0xFF16233B)

val ZakElectricBlue = Color(0xFF2563EB)
val ZakElectricBlueLight = Color(0xFF3B82F6)
val ZakSubtleCyan = Color(0xFF06B6D4)
val ZakLuminousCyan = Color(0xFF38BDF8)
val ZakCyanGlow = Color(0x3306B6D4)

val ZakUserBubbleDark = Color(0xFF1D4ED8)
val ZakAiBubbleDark = Color(0xFF11192B)

val ZakTextPrimaryDark = Color(0xFFF8FAFC)
val ZakTextSecondaryDark = Color(0xFF94A3B8)
val ZakTextMutedDark = Color(0xFF64748B)

// ZAK AI Light Brand Palette
val ZakLightBackground = Color(0xFFF8FAFC)
val ZakLightSurface = Color(0xFFFFFFFF)
val ZakLightSurfaceVariant = Color(0xFFF1F5F9)
val ZakLightBorder = Color(0xFFE2E8F0)
val ZakLightTextPrimary = Color(0xFF0F172A)
val ZakLightTextSecondary = Color(0xFF475569)
val ZakLightTextMuted = Color(0xFF94A3B8)
val ZakUserBubbleLight = Color(0xFF2563EB)
val ZakAiBubbleLight = Color(0xFFF1F5F9)

val ZakSuccess = Color(0xFF10B981)
val ZakWarning = Color(0xFFF59E0B)
val ZakError = Color(0xFFEF4444)
