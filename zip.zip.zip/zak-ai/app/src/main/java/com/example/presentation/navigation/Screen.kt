package com.example.presentation.navigation

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Chat : Screen("chat?conversationId={conversationId}") {
        fun createRoute(conversationId: String? = null): String {
            return if (conversationId != null) "chat?conversationId=$conversationId" else "chat"
        }
    }
    object Search : Screen("search")
    object Studio : Screen("studio")
    object Memory : Screen("memory")
    object Coding : Screen("coding")
    object Settings : Screen("settings")
    object Profile : Screen("profile")
}
