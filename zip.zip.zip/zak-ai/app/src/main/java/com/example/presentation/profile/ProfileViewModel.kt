package com.example.presentation.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.common.AppContainer
import com.example.core.model.UserProfile
import com.example.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ProfileUiState(
    val profile: UserProfile = UserProfile(),
    val isSaving: Boolean = false,
    val savedToast: Boolean = false
)

class ProfileViewModel(
    private val appContainer: AppContainer
) : ViewModel() {

    private val settingsRepository: SettingsRepository = appContainer.settingsRepository

    private val _uiState = MutableStateFlow(ProfileUiState())
    val uiState: StateFlow<ProfileUiState> = _uiState.asStateFlow()

    init {
        settingsRepository.userProfileFlow
            .onEach { prof -> _uiState.update { it.copy(profile = prof) } }
            .launchIn(viewModelScope)
    }

    fun onNameChanged(name: String) {
        _uiState.update { it.copy(profile = it.profile.copy(name = name)) }
    }

    fun onTitleChanged(title: String) {
        _uiState.update { it.copy(profile = it.profile.copy(title = title)) }
    }

    fun onAvatarColorChanged(colorHex: String) {
        _uiState.update { it.copy(profile = it.profile.copy(avatarColorHex = colorHex)) }
    }

    fun onCustomInstructionsChanged(instructions: String) {
        _uiState.update { it.copy(profile = it.profile.copy(customInstructions = instructions)) }
    }

    fun saveProfile() {
        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true) }
            settingsRepository.updateUserProfile(_uiState.value.profile)
            _uiState.update { it.copy(isSaving = false, savedToast = true) }
        }
    }

    fun clearToast() {
        _uiState.update { it.copy(savedToast = false) }
    }

    companion object {
        fun provideFactory(container: AppContainer): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return ProfileViewModel(container) as T
                }
            }
    }
}
