package com.example.core.network

import com.example.core.database.entity.MessageEntity
import com.example.core.model.AiModelConfig
import com.example.core.model.Attachment
import kotlinx.coroutines.flow.Flow

interface AiService {
    suspend fun generateResponse(
        prompt: String,
        history: List<MessageEntity>,
        modelConfig: AiModelConfig,
        systemPrompt: String? = null,
        attachment: Attachment? = null
    ): Result<String>

    fun streamResponse(
        prompt: String,
        history: List<MessageEntity>,
        modelConfig: AiModelConfig,
        systemPrompt: String? = null,
        attachment: Attachment? = null
    ): Flow<String>

    suspend fun isBackendConnected(): Boolean
}
