package com.example.core.model

enum class ChatRole {
    USER,
    AI,
    SYSTEM
}

enum class UsageState {
    READY,
    PROCESSING,
    RATE_LIMITED,
    OFFLINE,
    ERROR
}

data class AiModelConfig(
    val id: String,
    val name: String,
    val description: String,
    val maxTokens: Int = 8192,
    val isStreamingSupported: Boolean = true
) {
    companion object {
        val GEMINI_FLASH = AiModelConfig(
            id = "gemini-3.5-flash",
            name = "ZAK Neural-3.5 Flash",
            description = "High-speed reasoning, low latency, ideal for daily intelligence.",
            isStreamingSupported = true
        )
        val GEMINI_PRO = AiModelConfig(
            id = "gemini-3.1-pro-preview",
            name = "ZAK Neural-3.1 Pro",
            description = "Advanced reasoning, multi-step math, and complex code synthesis.",
            isStreamingSupported = true
        )

        val ALL_MODELS = listOf(GEMINI_FLASH, GEMINI_PRO)
    }
}

data class Attachment(
    val uriString: String,
    val displayName: String,
    val mimeType: String,
    val sizeBytes: Long = 0L
)

enum class ThemeMode {
    SYSTEM,
    LIGHT,
    DARK
}

data class UserProfile(
    val name: String = "User",
    val title: String = "AI Researcher & Builder",
    val avatarColorHex: String = "#2563EB",
    val customInstructions: String = ""
)
