package com.example.core.network

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import com.example.BuildConfig
import com.example.core.database.entity.MessageEntity
import com.example.core.model.AiModelConfig
import com.example.core.model.Attachment
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

class AiServiceImpl(
    private val context: Context,
    private val customBackendUrlProvider: () -> String? = { null },
    private val customDevKeyProvider: () -> String? = { null }
) : AiService {

    companion object {
        const val DEFAULT_GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/"
        const val PLACEHOLDER_KEY = "MY_GEMINI_API_KEY"

        const val FRIENDLY_ERROR_CONNECTION = "ZAK AI couldn't connect right now. Please try again in a moment."
        const val FRIENDLY_ERROR_TIMEOUT = "Your request took too long. Please try again."
        const val FRIENDLY_ERROR_RATE_LIMIT = "You've reached the current usage limit. Please try again later."
        const val FRIENDLY_ERROR_AUTH = "ZAK AI service authentication is currently unavailable. Please verify configuration."
    }

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val geminiApi: GeminiRestApi by lazy {
        Retrofit.Builder()
            .baseUrl(DEFAULT_GEMINI_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(GeminiRestApi::class.java)
    }

    private fun getBackendApi(baseUrl: String): SecureBackendApi {
        val url = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
        return Retrofit.Builder()
            .baseUrl(url)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(SecureBackendApi::class.java)
    }

    private fun resolveApiKey(): String? {
        val customKey = customDevKeyProvider()?.trim()
        if (!customKey.isNullOrEmpty()) return customKey

        val buildConfigKey = try {
            BuildConfig.GEMINI_API_KEY.trim()
        } catch (e: Throwable) {
            ""
        }
        if (buildConfigKey.isNotEmpty() && buildConfigKey != PLACEHOLDER_KEY) {
            return buildConfigKey
        }
        return null
    }

    override suspend fun isBackendConnected(): Boolean {
        val backendUrl = customBackendUrlProvider()?.trim()
        if (!backendUrl.isNullOrEmpty()) {
            return try {
                val resp = getBackendApi(backendUrl).healthCheck()
                resp.isSuccessful
            } catch (e: Exception) {
                false
            }
        }
        return resolveApiKey() != null
    }

    override suspend fun generateResponse(
        prompt: String,
        history: List<MessageEntity>,
        modelConfig: AiModelConfig,
        systemPrompt: String?,
        attachment: Attachment?
    ): Result<String> = withContext(Dispatchers.IO) {
        val backendUrl = customBackendUrlProvider()?.trim()
        if (!backendUrl.isNullOrEmpty()) {
            return@withContext callBackendGateway(backendUrl, prompt, history, modelConfig, systemPrompt)
        }

        val apiKey = resolveApiKey()
        if (apiKey.isNullOrEmpty()) {
            return@withContext Result.failure(Exception(FRIENDLY_ERROR_CONNECTION))
        }

        try {
            val request = buildGeminiRequest(prompt, history, systemPrompt, attachment)
            val response = geminiApi.generateContent(
                model = modelConfig.id,
                apiKey = apiKey,
                request = request
            )

            if (response.isSuccessful) {
                val candidateText = response.body()
                    ?.candidates
                    ?.firstOrNull()
                    ?.content
                    ?.parts
                    ?.mapNotNull { it.text }
                    ?.joinToString(separator = "")

                if (!candidateText.isNullOrBlank()) {
                    Result.success(candidateText)
                } else {
                    Result.failure(Exception(FRIENDLY_ERROR_CONNECTION))
                }
            } else {
                val code = response.code()
                val friendlyMessage = when (code) {
                    429 -> FRIENDLY_ERROR_RATE_LIMIT
                    401, 403 -> FRIENDLY_ERROR_AUTH
                    500, 502, 503, 504 -> FRIENDLY_ERROR_CONNECTION
                    else -> FRIENDLY_ERROR_CONNECTION
                }
                Result.failure(Exception(friendlyMessage))
            }
        } catch (e: SocketTimeoutException) {
            Result.failure(Exception(FRIENDLY_ERROR_TIMEOUT))
        } catch (e: UnknownHostException) {
            Result.failure(Exception(FRIENDLY_ERROR_CONNECTION))
        } catch (e: Exception) {
            Result.failure(Exception(FRIENDLY_ERROR_CONNECTION))
        }
    }

    override fun streamResponse(
        prompt: String,
        history: List<MessageEntity>,
        modelConfig: AiModelConfig,
        systemPrompt: String?,
        attachment: Attachment?
    ): Flow<String> = flow {
        val backendUrl = customBackendUrlProvider()?.trim()
        if (!backendUrl.isNullOrEmpty()) {
            val res = callBackendGateway(backendUrl, prompt, history, modelConfig, systemPrompt)
            res.onSuccess { emit(it) }.onFailure { throw it }
            return@flow
        }

        val apiKey = resolveApiKey()
        if (apiKey.isNullOrEmpty()) {
            throw Exception(FRIENDLY_ERROR_CONNECTION)
        }

        try {
            val request = buildGeminiRequest(prompt, history, systemPrompt, attachment)
            val response = geminiApi.streamGenerateContent(
                model = modelConfig.id,
                apiKey = apiKey,
                request = request
            )

            if (!response.isSuccessful) {
                val code = response.code()
                val msg = if (code == 429) FRIENDLY_ERROR_RATE_LIMIT else FRIENDLY_ERROR_CONNECTION
                throw Exception(msg)
            }

            val body = response.body() ?: throw Exception(FRIENDLY_ERROR_CONNECTION)
            body.byteStream().bufferedReader().use { reader ->
                var line: String?
                val chunkAdapter = moshi.adapter(GeminiResponse::class.java)
                while (reader.readLine().also { line = it } != null) {
                    val currentLine = line!!.trim()
                    if (currentLine.startsWith("data: ")) {
                        val jsonPart = currentLine.removePrefix("data: ").trim()
                        try {
                            val geminiResp = chunkAdapter.fromJson(jsonPart)
                            val text = geminiResp?.candidates
                                ?.firstOrNull()
                                ?.content
                                ?.parts
                                ?.mapNotNull { it.text }
                                ?.joinToString("")
                            if (!text.isNullOrEmpty()) {
                                emit(text)
                            }
                        } catch (_: Exception) {
                            // ignore partial frame parse error
                        }
                    } else if (currentLine.startsWith("{")) {
                        try {
                            val geminiResp = chunkAdapter.fromJson(currentLine)
                            val text = geminiResp?.candidates
                                ?.firstOrNull()
                                ?.content
                                ?.parts
                                ?.mapNotNull { it.text }
                                ?.joinToString("")
                            if (!text.isNullOrEmpty()) {
                                emit(text)
                            }
                        } catch (_: Exception) {}
                    }
                }
            }
        } catch (e: SocketTimeoutException) {
            throw Exception(FRIENDLY_ERROR_TIMEOUT)
        } catch (e: UnknownHostException) {
            throw Exception(FRIENDLY_ERROR_CONNECTION)
        } catch (e: Exception) {
            throw if (e.message?.contains("ZAK AI") == true || e.message?.contains("usage limit") == true) {
                e
            } else {
                Exception(FRIENDLY_ERROR_CONNECTION)
            }
        }
    }.flowOn(Dispatchers.IO)

    private suspend fun callBackendGateway(
        backendUrl: String,
        prompt: String,
        history: List<MessageEntity>,
        modelConfig: AiModelConfig,
        systemPrompt: String?
    ): Result<String> {
        return try {
            val api = getBackendApi(backendUrl)
            val historyItems = history.takeLast(10).map {
                BackendHistoryItem(role = it.role.lowercase(), text = it.content)
            }
            val request = SecureBackendChatRequest(
                model = modelConfig.id,
                message = prompt,
                history = historyItems,
                customInstructions = systemPrompt
            )
            val response = api.chat(null, request)
            if (response.isSuccessful && response.body()?.reply != null) {
                Result.success(response.body()!!.reply!!)
            } else {
                Result.failure(Exception(FRIENDLY_ERROR_CONNECTION))
            }
        } catch (e: Exception) {
            Result.failure(Exception(FRIENDLY_ERROR_CONNECTION))
        }
    }

    private fun buildGeminiRequest(
        prompt: String,
        history: List<MessageEntity>,
        systemPrompt: String?,
        attachment: Attachment?
    ): GeminiRequest {
        val contents = mutableListOf<GeminiContent>()

        // Add history turns (limit last 10 messages for context efficiency)
        val recentHistory = history.takeLast(10)
        for (item in recentHistory) {
            val role = if (item.role.equals("USER", ignoreCase = true)) "user" else "model"
            contents.add(
                GeminiContent(
                    role = role,
                    parts = listOf(GeminiContentPart(text = item.content))
                )
            )
        }

        // Build current prompt parts (supporting image attachments if available)
        val currentParts = mutableListOf<GeminiContentPart>()
        if (attachment != null && attachment.mimeType.startsWith("image/")) {
            val base64 = loadAttachmentBase64(attachment.uriString)
            if (base64 != null) {
                currentParts.add(
                    GeminiContentPart(
                        inlineData = GeminiInlineData(
                            mimeType = attachment.mimeType,
                            data = base64
                        )
                    )
                )
            }
        }
        currentParts.add(GeminiContentPart(text = prompt))

        contents.add(GeminiContent(role = "user", parts = currentParts))

        val systemInstruction = if (!systemPrompt.isNullOrBlank()) {
            GeminiContent(
                parts = listOf(
                    GeminiContentPart(
                        text = "You are ZAK AI, an elite, original personal AI assistant. " +
                                "Provide clear, well-structured, authoritative, and concise responses. " +
                                "Support markdown formatting with code blocks, lists, and headings when appropriate.\n\n" +
                                systemPrompt
                    )
                )
            )
        } else {
            GeminiContent(
                parts = listOf(
                    GeminiContentPart(
                        text = "You are ZAK AI, a professional, high-performance personal AI assistant. " +
                                "Deliver crisp, accurate, and direct answers using clean Markdown."
                    )
                )
            )
        }

        return GeminiRequest(
            contents = contents,
            systemInstruction = systemInstruction,
            generationConfig = GeminiGenerationConfig(
                temperature = 0.7f,
                topP = 0.95f,
                maxOutputTokens = 4096
            )
        )
    }

    private fun loadAttachmentBase64(uriString: String): String? {
        return try {
            val uri = Uri.parse(uriString)
            val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            inputStream?.close()
            if (bitmap != null) {
                val outputStream = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
                Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
            } else null
        } catch (e: Exception) {
            null
        }
    }
}
