package com.example.data.repository

import com.example.core.database.dao.MemoryDao
import com.example.core.database.entity.MemoryEntity
import com.example.domain.repository.MemoryRepository
import kotlinx.coroutines.flow.Flow

class MemoryRepositoryImpl(
    private val memoryDao: MemoryDao
) : MemoryRepository {

    override fun getMemories(): Flow<List<MemoryEntity>> {
        return memoryDao.getAllMemories()
    }

    override suspend fun addMemory(title: String, content: String, category: String): Long {
        val now = System.currentTimeMillis()
        val entity = MemoryEntity(
            title = title.trim(),
            content = content.trim(),
            category = category.trim().ifBlank { "General" },
            createdAt = now,
            updatedAt = now
        )
        return memoryDao.insertMemory(entity)
    }

    override suspend fun updateMemory(id: Long, title: String, content: String, category: String) {
        val entity = MemoryEntity(
            id = id,
            title = title.trim(),
            content = content.trim(),
            category = category.trim().ifBlank { "General" },
            updatedAt = System.currentTimeMillis()
        )
        memoryDao.updateMemory(entity)
    }

    override suspend fun deleteMemory(id: Long) {
        memoryDao.deleteMemory(id)
    }

    override suspend fun clearAllMemories() {
        memoryDao.deleteAllMemories()
    }
}
