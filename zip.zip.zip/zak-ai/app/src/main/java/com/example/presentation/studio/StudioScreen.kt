package com.example.presentation.studio

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.presentation.components.MarkdownText
import com.example.ui.theme.ZakBorderDark
import com.example.ui.theme.ZakElectricBlue
import com.example.ui.theme.ZakError
import com.example.ui.theme.ZakLuminousCyan
import com.example.ui.theme.ZakSubtleCyan
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun StudioScreen(
    viewModel: StudioViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onNavigateBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "ZAK AI Studio",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        letterSpacing = 1.sp
                    )
                )
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .imePadding()
        ) {
            // Tab Row
            TabRow(
                selectedTabIndex = uiState.activeTab.ordinal,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = ZakLuminousCyan,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[uiState.activeTab.ordinal]),
                        color = ZakSubtleCyan,
                        height = 3.dp
                    )
                }
            ) {
                Tab(
                    selected = uiState.activeTab == StudioTab.CODE_SYNTHESIS,
                    onClick = { viewModel.setTab(StudioTab.CODE_SYNTHESIS) },
                    text = { Text("Code Synthesis", fontSize = 13.sp) },
                    icon = { Icon(Icons.Default.Code, contentDescription = null, modifier = Modifier.size(18.dp)) }
                )
                Tab(
                    selected = uiState.activeTab == StudioTab.TEXT_STUDIO,
                    onClick = { viewModel.setTab(StudioTab.TEXT_STUDIO) },
                    text = { Text("Text Studio", fontSize = 13.sp) },
                    icon = { Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(18.dp)) }
                )
                Tab(
                    selected = uiState.activeTab == StudioTab.IMAGE_STUDIO,
                    onClick = { viewModel.setTab(StudioTab.IMAGE_STUDIO) },
                    text = { Text("Image Studio", fontSize = 13.sp) },
                    icon = { Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(18.dp)) }
                )
            }

            // Tab Content
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (uiState.activeTab) {
                    StudioTab.CODE_SYNTHESIS -> CodeSynthesisTab(uiState, viewModel)
                    StudioTab.TEXT_STUDIO -> TextStudioTab(uiState, viewModel)
                    StudioTab.IMAGE_STUDIO -> ImageStudioTab(uiState, viewModel)
                }
            }
        }
    }
}

@Composable
private fun CodeSynthesisTab(
    state: StudioUiState,
    viewModel: StudioViewModel
) {
    val languages = listOf("Kotlin", "Python", "TypeScript", "Rust", "Go", "SQL", "C++")
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "TARGET LANGUAGE",
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                letterSpacing = 1.sp
            )
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            languages.forEach { lang ->
                val isSelected = state.codeLanguage == lang
                FilterChip(
                    selected = isSelected,
                    onClick = { viewModel.onCodeLanguageChanged(lang) },
                    label = { Text(lang, fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = ZakElectricBlue.copy(alpha = 0.25f),
                        selectedLabelColor = ZakLuminousCyan
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = isSelected,
                        borderColor = ZakBorderDark,
                        selectedBorderColor = ZakSubtleCyan
                    )
                )
            }
        }

        OutlinedTextField(
            value = state.codePrompt,
            onValueChange = { viewModel.onCodePromptChanged(it) },
            placeholder = { Text("Describe the algorithm, data structure, or service to synthesize...") },
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                focusedBorderColor = ZakSubtleCyan,
                unfocusedBorderColor = ZakBorderDark
            )
        )

        Button(
            onClick = { viewModel.generateCode() },
            enabled = state.codePrompt.isNotBlank() && !state.isGeneratingCode,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = ZakElectricBlue,
                contentColor = Color.White
            )
        ) {
            if (state.isGeneratingCode) {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Synthesizing Code...")
            } else {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Synthesize Code")
            }
        }

        if (state.codeError != null) {
            Text(
                text = state.codeError,
                color = ZakError,
                style = MaterialTheme.typography.bodySmall
            )
        }

        if (state.generatedCode.isNotEmpty()) {
            Text(
                text = "SYNTHESIZED OUTPUT",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = ZakLuminousCyan,
                    letterSpacing = 1.sp
                )
            )
            MarkdownText(markdown = state.generatedCode)
        }
    }
}

@Composable
private fun TextStudioTab(
    state: StudioUiState,
    viewModel: StudioViewModel
) {
    val tones = listOf("Concise & Executive", "Technical Deep-Dive", "Persuasive Pitch", "Creative Exploratory")
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "TONE & STYLE",
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                letterSpacing = 1.sp
            )
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            tones.forEach { tone ->
                val isSelected = state.textTone == tone
                FilterChip(
                    selected = isSelected,
                    onClick = { viewModel.onTextToneChanged(tone) },
                    label = { Text(tone, fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = ZakElectricBlue.copy(alpha = 0.25f),
                        selectedLabelColor = ZakLuminousCyan
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = isSelected,
                        borderColor = ZakBorderDark,
                        selectedBorderColor = ZakSubtleCyan
                    )
                )
            }
        }

        OutlinedTextField(
            value = state.textPrompt,
            onValueChange = { viewModel.onTextPromptChanged(it) },
            placeholder = { Text("Enter topic, draft, outline, or thesis to articulate...") },
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                focusedBorderColor = ZakSubtleCyan,
                unfocusedBorderColor = ZakBorderDark
            )
        )

        Button(
            onClick = { viewModel.generateText() },
            enabled = state.textPrompt.isNotBlank() && !state.isGeneratingText,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = ZakElectricBlue,
                contentColor = Color.White
            )
        ) {
            if (state.isGeneratingText) {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Drafting Content...")
            } else {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Generate Draft")
            }
        }

        if (state.textError != null) {
            Text(
                text = state.textError,
                color = ZakError,
                style = MaterialTheme.typography.bodySmall
            )
        }

        if (state.generatedText.isNotEmpty()) {
            Text(
                text = "ARTICULATED DRAFT",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = ZakLuminousCyan,
                    letterSpacing = 1.sp
                )
            )
            MarkdownText(markdown = state.generatedText)
        }
    }
}

@Composable
private fun ImageStudioTab(
    state: StudioUiState,
    viewModel: StudioViewModel
) {
    val aspectRatios = listOf("1:1", "16:9", "9:16", "4:3")
    val styles = listOf("Photorealistic Cybernetic", "Minimalist Vector", "Cinematic Dark", "Technical Blueprint")
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "ASPECT RATIO",
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                letterSpacing = 1.sp
            )
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            aspectRatios.forEach { ratio ->
                val isSelected = state.selectedAspectRatio == ratio
                FilterChip(
                    selected = isSelected,
                    onClick = { viewModel.onAspectRatioChanged(ratio) },
                    label = { Text(ratio, fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = ZakElectricBlue.copy(alpha = 0.25f),
                        selectedLabelColor = ZakLuminousCyan
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = isSelected,
                        borderColor = ZakBorderDark,
                        selectedBorderColor = ZakSubtleCyan
                    )
                )
            }
        }

        Text(
            text = "STYLE PRESET",
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                letterSpacing = 1.sp
            )
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            styles.forEach { st ->
                val isSelected = state.selectedStyle == st
                FilterChip(
                    selected = isSelected,
                    onClick = { viewModel.onImageStyleChanged(st) },
                    label = { Text(st, fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = ZakElectricBlue.copy(alpha = 0.25f),
                        selectedLabelColor = ZakLuminousCyan
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = isSelected,
                        borderColor = ZakBorderDark,
                        selectedBorderColor = ZakSubtleCyan
                    )
                )
            }
        }

        OutlinedTextField(
            value = state.imagePrompt,
            onValueChange = { viewModel.onImagePromptChanged(it) },
            placeholder = { Text("Describe image concept, scene lighting, and subjects...") },
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                focusedBorderColor = ZakSubtleCyan,
                unfocusedBorderColor = ZakBorderDark
            )
        )

        Button(
            onClick = { viewModel.submitImageRequest() },
            enabled = state.imagePrompt.isNotBlank(),
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = ZakElectricBlue,
                contentColor = Color.White
            )
        ) {
            Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Synthesize Image Request")
        }

        if (state.imageStatusMessage != null) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = androidx.compose.foundation.BorderStroke(1.dp, ZakSubtleCyan.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Image Synthesis Specification",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        color = ZakLuminousCyan
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = state.imageStatusMessage,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurface,
                            lineHeight = 18.sp
                        )
                    )
                }
            }
        }
    }
}
